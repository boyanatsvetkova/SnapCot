# SnapCot
Final Telerik Academy ASP.NET MVC 5 Project
