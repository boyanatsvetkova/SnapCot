﻿namespace SnapCot.Data.Models
{
    public enum ShippingTerms
    {
        Exworks = 0,
        DdpDelivery = 1
    }
}
