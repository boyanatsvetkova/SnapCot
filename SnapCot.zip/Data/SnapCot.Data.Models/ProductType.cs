﻿namespace SnapCot.Data.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public enum ProductType
    {
        Liquid = 0,
        Powder = 1,
        Pellettes = 2
    }
}
