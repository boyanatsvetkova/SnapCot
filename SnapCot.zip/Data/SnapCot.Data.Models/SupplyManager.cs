﻿namespace SnapCot.Data.Models
{
    public class SupplyManager : User
    {
    }
}
