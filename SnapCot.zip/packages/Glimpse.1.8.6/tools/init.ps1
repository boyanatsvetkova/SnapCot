param($installPath, $toolsPath, $package)

Import-Module (Join-Path $toolsPath glimpse.psm1)