﻿param($installPath, $toolsPath, $package, $project)

Register-GlimpseExtension $package $DTE